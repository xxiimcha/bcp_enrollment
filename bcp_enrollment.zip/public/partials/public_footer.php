</div>

<!-- Footer -->
<footer class="footer mt-5">
    <p>&copy; 2025 Bestlink College of the Philippines | All Rights Reserved</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
